package com.example.beans;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class GstinResponseBean {

	private List<StatusBean> data;

	public List<StatusBean> getData() {
		return data;
	}

	public void setData(List<StatusBean> data) {
		this.data = data;
	}


}
