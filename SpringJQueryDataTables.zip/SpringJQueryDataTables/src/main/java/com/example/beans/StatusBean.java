package com.example.beans;

public class StatusBean {

	private String symbol;
	private String open;
	private String high;
	private String low;
	private String ltP;
	private Long totalBuyQuantity;
	private Long totalSellQuantity;
	private Long differenceQty;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getOpen() {
		return open;
	}
	public void setOpen(String open) {
		this.open = open;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	public String getLtP() {
		return ltP;
	}
	public void setLtP(String ltP) {
		this.ltP = ltP;
	}
	public Long getTotalBuyQuantity() {
		return totalBuyQuantity;
	}
	public void setTotalBuyQuantity(Long totalBuyQuantity) {
		this.totalBuyQuantity = totalBuyQuantity;
	}
	public Long getTotalSellQuantity() {
		return totalSellQuantity;
	}
	public void setTotalSellQuantity(Long totalSellQuantity) {
		this.totalSellQuantity = totalSellQuantity;
	}
	public Long getDifferenceQty() {
		return differenceQty;
	}
	public void setDifferenceQty(Long differenceQty) {
		this.differenceQty = differenceQty;
	}

}
