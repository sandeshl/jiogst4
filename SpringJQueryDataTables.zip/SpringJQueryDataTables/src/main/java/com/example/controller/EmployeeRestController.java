package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.EmployeeServiceImpl;

@RestController
public class EmployeeRestController {
	
	@Autowired
	private EmployeeServiceImpl employeeService;
	
	@RequestMapping(path="/employees", method=RequestMethod.GET)
	public String getAllEmployees(){
		String json=employeeService.getAllEmployees();
		 System.out.println("FINAL JSON ====="+json);
		return json;		
	}
}
