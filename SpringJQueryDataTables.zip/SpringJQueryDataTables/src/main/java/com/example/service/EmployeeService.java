package com.example.service;

public interface EmployeeService {
	String getAllEmployees();	
}
