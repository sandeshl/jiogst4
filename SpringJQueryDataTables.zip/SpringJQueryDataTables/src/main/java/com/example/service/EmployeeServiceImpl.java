package com.example.service;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.example.beans.GstinResponseBean;
import com.example.beans.StatusBean;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

public String getAllEmployees(){
		
		GstinResponseBean response = new GstinResponseBean();
		StatusBean statusBean = new StatusBean();
		JSONArray jsonArray=new JSONArray();
		String userGstinJsonData="";
		try{
		final String uri = "https://www.nseindia.com/live_market/dynaContent/live_watch/stock_watch/foSecStockWatch.json";
	     
	    RestTemplate restTemplate = new RestTemplate();
	    ResponseEntity<String> responseEntity=restTemplate.exchange(uri, HttpMethod.GET ,null, String.class);
	    String jsonString=responseEntity.getBody();
	    JSONObject jsonObject = new JSONObject(jsonString);
	    System.out.println("Symbol====="+responseEntity);	
	    System.out.println("jsonObject====="+jsonObject);	
	    String symbol=null;
	    String open=null;
	    String high=null;
	    String low=null;
	    String ltP=null;
	    long totalBuyQuantity=0;
		long totalSellQuantity=0;
		long differenceQty=0;
		double percentageDiffQty=0;
		double finalPercentageDiffQty=0;
		
	    if(jsonObject.has("data")){
	    	JSONArray objKeyObject = jsonObject.getJSONArray("data");
	    	for(int i =0; i<objKeyObject.length();i++){
	    		JSONObject gstnListObj=new JSONObject();	
				JSONObject obj = objKeyObject.getJSONObject(i);
				if(obj.has("symbol")){
				    symbol=obj.getString("symbol");
				}
				if(obj.has("open")){
					open=obj.getString("open");
				}
				if(obj.has("high")){
					high=obj.getString("high");
				}
				if(obj.has("low")){
					low=obj.getString("low");
				}
				if(obj.has("ltP")){
					ltP=obj.getString("ltP");
				}				
				System.out.println("symbol====="+symbol);	
				System.out.println("open====="+open);	
				System.out.println("high====="+high);	
				System.out.println("low====="+low);	
				System.out.println("ltP====="+ltP);	
				if(symbol !=null && !"".equalsIgnoreCase(symbol)){
				final String uri1 = "https://beta.nseindia.com/api/quote-equity?symbol="+symbol+"&section=trade_info";	     
				ResponseEntity<String> responseEntity1=restTemplate.exchange(uri1, HttpMethod.GET ,null, String.class);	  
				
				String jsonString1=responseEntity1.getBody();
				if(jsonString1 !=null && !"".equalsIgnoreCase(jsonString1)){
				JSONObject jsonObject1 = new JSONObject(jsonString1);
				
				System.out.println("Data====="+responseEntity1);
				System.out.println("jsonObject1====="+jsonObject1);	
				
				 if(jsonObject1.has("marketDeptOrderBook")){
					
					 JSONObject objKeyObjectString = jsonObject1.getJSONObject("marketDeptOrderBook"); 
					 if(objKeyObjectString.has("totalSellQuantity")){
					 totalBuyQuantity=objKeyObjectString.getLong("totalBuyQuantity") ;
					 System.out.println("totalBuyQuantity====="+totalBuyQuantity);
					 }
					 if(objKeyObjectString.has("totalSellQuantity")){
					 totalSellQuantity=objKeyObjectString.getLong("totalSellQuantity") ;
					 System.out.println("totalSellQuantity====="+totalSellQuantity);
					 differenceQty=totalBuyQuantity-totalSellQuantity;
					 System.out.println("differenceQty====="+differenceQty);
					 }	
					 
				 }
				
				}
				}
				statusBean.setSymbol(symbol);
				statusBean.setOpen(open);
				statusBean.setHigh(high);
				statusBean.setLow(low);
				statusBean.setLtP(ltP);
				statusBean.setTotalBuyQuantity(totalBuyQuantity);
				statusBean.setTotalSellQuantity(totalSellQuantity);
				statusBean.setDifferenceQty(differenceQty);
				percentageDiffQty=totalBuyQuantity-totalSellQuantity;
				finalPercentageDiffQty=percentageDiffQty/totalSellQuantity;
				finalPercentageDiffQty=finalPercentageDiffQty*100;
				gstnListObj.put("symbol", symbol);
				gstnListObj.put("open", open);
				gstnListObj.put("high", high);
				gstnListObj.put("low", low);
				gstnListObj.put("ltP", ltP);
				gstnListObj.put("totalBuyQuantity", totalBuyQuantity);
				gstnListObj.put("totalSellQuantity", totalSellQuantity);
				gstnListObj.put("differenceQty", differenceQty);				
				
				BigDecimal bigDecimal = new BigDecimal(finalPercentageDiffQty);
		        BigDecimal roundedWithScale = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);		      
		        
				gstnListObj.put("finalPercentageDiffQty", roundedWithScale);
				jsonArray.put(gstnListObj);
				if(jsonArray != null && jsonArray.length() > 0 ){
					userGstinJsonData = "{\"data\":" + jsonArray + "}";	
				}else{
					
				}
				
			}
	    	//response.setData(statusBean);
	    }
	    
	   
		}catch(RestClientException e){
		e.printStackTrace();	
		}
		
		return userGstinJsonData;
		
	}
	

}
