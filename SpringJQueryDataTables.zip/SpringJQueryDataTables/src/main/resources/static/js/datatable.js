$(document).ready( function () {
	 /*var table = $('#employeesTable').DataTable({
			"sAjaxSource": "/employees",
			"sAjaxDataProp": "",
			"aoColumns": [
			      { data: "symbol"},
		          { data: "ltP" },
				  { data: "totalBuyQuantity" },
				  { data: "totalSellQuantity" },
				  { data: "differenceQty" },
				  { data: "open" },
				  { data: "high" },
				  { data: "ltP" }	
		 ]
	 })*/


$('#employeesTable').DataTable( {
    dom: "Bfrtip",
    ajax: {
        url: "/employees",
        type: 'GET',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
    },
    columns: [
    	{ "data": "symbol"},
        { "data": "ltP" },
		  { "data": "totalBuyQuantity" },
		  { "data": "totalSellQuantity" },
		  { "data": "differenceQty" },
		  { "data": "finalPercentageDiffQty" },
		  { "data": "open" },
		  { "data": "high" },
		  { "data": "ltP" }	
    ],
    "bPaginate": false
    //select: true,
} );
});
